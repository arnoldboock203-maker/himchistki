const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'db.json');

const DEFAULT_DB = {
  settings: {
    studioName: 'KRYSTAL BAY',
    ownerName: 'Олег Ковальчук',
    bookingPhone: '+38 (067) 480-92-15',
    city: 'Київ',
    address: 'вул. Саперно-Слобідська, 24',
    workHours: '09:00 – 21:00',
    aboutText: 'Глибока парова екстракція, відновлення шкіри та алькантари, озонація без запаху хімії. Усі реальні роботи в портфоліо підтягуються напряму з нашого Instagram.',
    igHandle: '@krystalbay.kyiv',
    igAccessToken: '',
    lastSync: 'Очікує синхронізації'
  },
  categories: [
    'Повна хімчистка',
    'Шкіра та алькантара',
    'Парова екстракція',
    'Озонація та антизапах',
    'Відео / Reels'
  ],
  igPosts: [
    {
      id: 'ig_901',
      igCode: 'C8xK2mQp1',
      mediaType: 'VIDEO',
      duration: '0:28',
      image: '/images/cockpit.jpg',
      mediaUrl: '',
      permalink: 'https://instagram.com',
      title: 'Range Rover Sport — Повна хімчистка + кераміка шкіри',
      carModel: 'Range Rover Sport 2023',
      workTime: '8 год',
      category: 'Повна хімчистка',
      published: true,
      featured: true,
      likes: 418,
      views: '14.2K',
      date: '2 год тому',
      igCaption: 'Повне оновлення кокпіту Range Rover Sport. Повернули заводський матовий фініш шкірі та прибрали сліди глянцю на кермі.'
    },
    {
      id: 'ig_902',
      igCode: 'C8wR9vLm4',
      mediaType: 'PHOTO',
      duration: '',
      image: '/images/leather.jpg',
      mediaUrl: '',
      permalink: 'https://instagram.com',
      title: 'BMW X5 G05 — Відновлення перфорованої шкіри Merino',
      carModel: 'BMW X5 G05',
      workTime: '5 год',
      category: 'Шкіра та алькантара',
      published: true,
      featured: true,
      likes: 329,
      views: '6.8K',
      date: '1 день тому',
      igCaption: 'Делікатне очищення перфорації без розмочування. Захист лосьйоном Colourlock — шкіра знову мʼяка і матова.'
    },
    {
      id: 'ig_903',
      igCode: 'C8uT4nWz8',
      mediaType: 'VIDEO',
      duration: '0:19',
      image: '/images/steam.jpg',
      mediaUrl: '',
      permalink: 'https://instagram.com',
      title: 'Audi Q7 — Глибока парова екстракція підлоги',
      carModel: 'Audi Q7 50 TDI',
      workTime: '6.5 год',
      category: 'Парова екстракція',
      published: true,
      featured: false,
      likes: 512,
      views: '22.5K',
      date: '2 дні тому',
      igCaption: 'Зимова сіль та плями кави в ковроліні? Пар 140°C + екстрактор витягують бруд з самої основи ворсу.'
    },
    {
      id: 'ig_904',
      igCode: 'C8sP1kYb2',
      mediaType: 'PHOTO',
      duration: '',
      image: '/images/alcantara.jpg',
      mediaUrl: '',
      permalink: 'https://instagram.com',
      title: 'Porsche 911 — Реставрація ворсу алькантари керма та стелі',
      carModel: 'Porsche 911 Carrera',
      workTime: '4 год',
      category: 'Шкіра та алькантара',
      published: true,
      featured: true,
      likes: 640,
      views: '11.4K',
      date: '4 дні тому',
      igCaption: 'Зняли засаленість з алькантари та підняли фірмовий оксамитовий ворс.'
    },
    {
      id: 'ig_905',
      igCode: 'C8pL7xDq5',
      mediaType: 'PHOTO',
      duration: '',
      image: '/images/ozone.jpg',
      mediaUrl: '',
      permalink: 'https://instagram.com',
      title: 'Mercedes S-Class — Озонація салону та повітроводів',
      carModel: 'Mercedes-Benz S500',
      workTime: '2 год',
      category: 'Озонація та антизапах',
      published: true,
      featured: false,
      likes: 204,
      views: '4.9K',
      date: '5 днів тому',
      igCaption: 'Повна нейтралізація запаху тютюну після попереднього власника. 2 цикли промислової озонації.'
    },
    {
      id: 'ig_906',
      igCode: 'C8mV3cJn9',
      mediaType: 'VIDEO',
      duration: '0:34',
      image: '/images/hero.jpg',
      mediaUrl: '',
      permalink: 'https://instagram.com',
      title: 'Audi A8 — Комплексна підготовка салону під LED-контролем',
      carModel: 'Audi A8 L',
      workTime: '7.5 год',
      category: 'Відео / Reels',
      published: true,
      featured: false,
      likes: 487,
      views: '18.9K',
      date: '1 тиждень тому',
      igCaption: 'Як виглядає салон після 7 годин педантичної роботи в нашому темному боксі.'
    }
  ],
  applications: [
    {
      id: 'KB-2047',
      type: 'booking',
      status: 'new',
      createdAt: 'Сьогодні, 09:40',
      clientName: 'Олександр Коваленко',
      phone: '+38 (067) 512-33-09',
      contactMethod: 'Telegram',
      carClass: 'Кросовер / SUV',
      carModel: 'BMW X5 2021',
      serviceSummary: 'Повна хімчистка салону',
      dateSlot: 'Завтра, 10:00',
      estimatedPrice: 5760,
      comment: 'Світла шкіра, є сліди від джинсів на водійському сидінні.'
    },
    {
      id: 'VC-108',
      type: 'vacancy',
      status: 'new',
      createdAt: 'Вчора, 18:15',
      clientName: 'Дмитро Савченко',
      phone: '+38 (093) 844-19-20',
      contactMethod: 'Телефон',
      vacancyTitle: 'Майстер хімчистки салону авто',
      experience: '2.5 роки в детейлінгу',
      comment: 'Працював з Koch-Chemie та Tornador, готовий вийти на тестовий день.'
    }
  ]
};

function ensureDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2), 'utf-8');
  }
}

function readDb() {
  ensureDb();
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  const data = JSON.parse(raw);
  data.settings = Object.assign({}, DEFAULT_DB.settings, data.settings || {});
  return data;
}

function writeDb(data) {
  const tmpPath = DB_PATH + '.tmp';
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpPath, DB_PATH);
}

module.exports = { readDb, writeDb, DEFAULT_DB };
