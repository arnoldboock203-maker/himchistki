const { readDb, writeDb } = require('./store');

/**
 * Реальна синхронізація постів та Reels з Instagram Graph API.
 * Зберігає нові публікації зі статусом published: false, щоб адмін сам
 * вирішував, що показувати на сайті та в яку категорію віднести.
 */
async function syncFromInstagram() {
  const db = readDb();
  const token = (db.settings.igAccessToken || process.env.INSTAGRAM_ACCESS_TOKEN || '').trim();

  if (!token) {
    return {
      ok: false,
      mode: 'no_token',
      message: 'Не вказано INSTAGRAM_ACCESS_TOKEN. Додайте токен у .env або на вкладці «Налаштування» в адмін-панелі.'
    };
  }

  const fields = 'id,caption,media_type,media_url,thumbnail_url,permalink,timestamp,username';
  const url = `https://graph.instagram.com/me/media?fields=${fields}&limit=25&access_token=${encodeURIComponent(token)}`;

  const response = await fetch(url);
  const payload = await response.json();

  if (!response.ok || payload.error) {
    return {
      ok: false,
      mode: 'api_error',
      message: payload.error?.message || `Помилка Instagram API (HTTP ${response.status})`
    };
  }

  const items = Array.isArray(payload.data) ? payload.data : [];
  const existingById = new Map(db.igPosts.map(p => [p.id, p]));
  const defaultCategory = db.categories[0] || 'Повна хімчистка';
  let added = 0;
  let updated = 0;

  for (const item of items) {
    const postId = `ig_${item.id}`;
    const isVideo = item.media_type === 'VIDEO';
    const previewImg = isVideo
      ? (item.thumbnail_url || item.media_url || '/images/cockpit.jpg')
      : (item.media_url || '/images/cockpit.jpg');
    const caption = (item.caption || '').trim();
    const firstLine = caption.split('\n')[0].slice(0, 76) || 'Робота з Instagram';

    if (item.username && !db.settings.igHandle) {
      db.settings.igHandle = '@' + item.username;
    }

    if (existingById.has(postId)) {
      // Оновлюємо лише свіжі медіа-посилання (Instagram CDN URLs мають термін дії), не чіпаючи вибір адміна!
      const cur = existingById.get(postId);
      cur.image = previewImg;
      cur.mediaUrl = item.media_url || cur.mediaUrl;
      cur.permalink = item.permalink || cur.permalink;
      updated++;
    } else {
      db.igPosts.unshift({
        id: postId,
        igCode: String(item.id).slice(-9),
        mediaType: isVideo ? 'VIDEO' : 'PHOTO',
        duration: isVideo ? 'REELS' : '',
        image: previewImg,
        mediaUrl: item.media_url || '',
        permalink: item.permalink || '',
        title: firstLine,
        carModel: 'Кейс з Instagram',
        workTime: 'За запитом',
        category: defaultCategory,
        published: false,
        featured: false,
        likes: 0,
        views: 'IG Live',
        date: item.timestamp ? new Date(item.timestamp).toLocaleDateString('uk-UA') : 'Щойно',
        igCaption: caption
      });
      added++;
    }
  }

  db.settings.lastSync = new Date().toLocaleString('uk-UA', {
    day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
  });
  writeDb(db);

  return {
    ok: true,
    mode: 'live',
    added,
    updated,
    total: db.igPosts.length,
    lastSync: db.settings.lastSync
  };
}

module.exports = { syncFromInstagram };
