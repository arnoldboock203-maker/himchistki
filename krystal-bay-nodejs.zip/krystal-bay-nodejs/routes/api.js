const express = require('express');
const router = express.Router();
const { readDb, writeDb } = require('../services/store');
const { syncFromInstagram } = require('../services/instagramSync');

// --- SETTINGS ---
router.get('/settings', (req, res) => {
  const db = readDb();
  res.json({
    ...db.settings,
    hasToken: Boolean((db.settings.igAccessToken || process.env.INSTAGRAM_ACCESS_TOKEN || '').trim()),
    igAccessToken: db.settings.igAccessToken ? '••••••••' : ''
  });
});

router.put('/settings', (req, res) => {
  const db = readDb();
  const b = req.body || {};
  const fields = ['studioName', 'ownerName', 'bookingPhone', 'city', 'address', 'workHours', 'aboutText', 'igHandle'];
  fields.forEach(k => {
    if (typeof b[k] === 'string' && b[k].trim() !== '') {
      db.settings[k] = k === 'igHandle' && !b[k].trim().startsWith('@') ? '@' + b[k].trim() : b[k].trim();
    }
  });
  if (typeof b.igAccessToken === 'string' && b.igAccessToken.trim() !== '' && b.igAccessToken !== '••••••••') {
    db.settings.igAccessToken = b.igAccessToken.trim();
  }
  writeDb(db);
  res.json({ ok: true, settings: db.settings });
});

// --- INSTAGRAM SYNC ---
router.post('/instagram/sync', async (req, res) => {
  try {
    const result = await syncFromInstagram();
    res.status(result.ok ? 200 : 400).json(result);
  } catch (err) {
    res.status(500).json({ ok: false, message: err.message || 'Помилка синхронізації з Instagram' });
  }
});

// --- POSTS ---
router.get('/posts', (req, res) => {
  const db = readDb();
  const onlyPublished = req.query.published === 'true';
  const posts = onlyPublished ? db.igPosts.filter(p => p.published) : db.igPosts;
  res.json({ posts, categories: db.categories, lastSync: db.settings.lastSync });
});

router.post('/posts', (req, res) => {
  const db = readDb();
  const b = req.body || {};
  const post = {
    id: 'ig_' + Date.now(),
    igCode: 'MAN' + Math.random().toString(36).slice(2, 7).toUpperCase(),
    mediaType: b.mediaType === 'VIDEO' ? 'VIDEO' : 'PHOTO',
    duration: b.mediaType === 'VIDEO' ? (b.duration || '0:25') : '',
    image: b.image || '/images/cockpit.jpg',
    mediaUrl: b.mediaUrl || '',
    permalink: b.permalink || '',
    title: (b.title || 'Нова робота').trim(),
    carModel: (b.carModel || 'Авто').trim(),
    workTime: (b.workTime || '6 год').trim(),
    category: b.category || db.categories[0] || 'Повна хімчистка',
    published: Boolean(b.published),
    featured: Boolean(b.featured),
    likes: Number(b.likes || 0),
    views: b.views || 'IG',
    date: 'Щойно',
    igCaption: (b.igCaption || '').trim()
  };
  db.igPosts.unshift(post);
  writeDb(db);
  res.status(201).json({ ok: true, post });
});

router.patch('/posts/:id', (req, res) => {
  const db = readDb();
  const post = db.igPosts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ ok: false, message: 'Пост не знайдено' });

  const b = req.body || {};
  if (typeof b.published === 'boolean') post.published = b.published;
  if (typeof b.featured === 'boolean') post.featured = b.featured;
  if (typeof b.category === 'string') post.category = b.category;
  if (typeof b.title === 'string' && b.title.trim()) post.title = b.title.trim();
  if (typeof b.carModel === 'string' && b.carModel.trim()) post.carModel = b.carModel.trim();
  if (typeof b.workTime === 'string' && b.workTime.trim()) post.workTime = b.workTime.trim();

  writeDb(db);
  res.json({ ok: true, post });
});

router.delete('/posts/:id', (req, res) => {
  const db = readDb();
  db.igPosts = db.igPosts.filter(p => p.id !== req.params.id);
  writeDb(db);
  res.json({ ok: true });
});

// --- CATEGORIES ---
router.post('/categories', (req, res) => {
  const db = readDb();
  const name = (req.body?.name || '').trim();
  if (!name) return res.status(400).json({ ok: false, message: 'Введіть назву категорії' });
  if (!db.categories.includes(name)) {
    db.categories.push(name);
    writeDb(db);
  }
  res.status(201).json({ ok: true, categories: db.categories });
});

router.delete('/categories/:name', (req, res) => {
  const db = readDb();
  const name = decodeURIComponent(req.params.name);
  if (db.categories.length <= 1) {
    return res.status(400).json({ ok: false, message: 'Має залишитись хоча б одна категорія' });
  }
  db.categories = db.categories.filter(c => c !== name);
  const fallback = db.categories[0];
  db.igPosts.forEach(p => { if (p.category === name) p.category = fallback; });
  writeDb(db);
  res.json({ ok: true, categories: db.categories });
});

// --- APPLICATIONS (BOOKINGS & VACANCIES) ---
router.get('/applications', (req, res) => {
  const db = readDb();
  res.json({ applications: db.applications });
});

router.post('/applications', (req, res) => {
  const db = readDb();
  const b = req.body || {};
  const isVacancy = b.type === 'vacancy';
  const entry = {
    id: (isVacancy ? 'VC-' : 'KB-') + (2048 + db.applications.length),
    type: isVacancy ? 'vacancy' : 'booking',
    status: 'new',
    createdAt: new Date().toLocaleString('uk-UA', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }),
    clientName: (b.clientName || '').trim(),
    phone: (b.phone || '').trim(),
    contactMethod: b.contactMethod || 'Telegram',
    carClass: b.carClass || '',
    carModel: b.carModel || '',
    serviceSummary: b.serviceSummary || '',
    dateSlot: b.dateSlot || '',
    estimatedPrice: Number(b.estimatedPrice || 0),
    vacancyTitle: b.vacancyTitle || '',
    experience: b.experience || '',
    comment: (b.comment || '').trim()
  };
  if (!entry.clientName || !entry.phone) {
    return res.status(400).json({ ok: false, message: 'Вкажіть імʼя та телефон' });
  }
  db.applications.unshift(entry);
  writeDb(db);
  res.status(201).json({ ok: true, application: entry });
});

router.patch('/applications/:id', (req, res) => {
  const db = readDb();
  const app = db.applications.find(a => a.id === req.params.id);
  if (!app) return res.status(404).json({ ok: false, message: 'Заявку не знайдено' });
  if (['new', 'in_progress', 'done'].includes(req.body?.status)) {
    app.status = req.body.status;
    writeDb(db);
  }
  res.json({ ok: true, application: app });
});

module.exports = router;
