(function () {
  if (window.lucide) window.lucide.createIcons();

  function toast(msg) {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    el.className = 'pointer-events-auto bg-[#09090a] border border-[#00a0e3] px-4 py-3 rounded-[2px] text-xs text-white shadow-xl';
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3200);
  }

  // SERVICES CALCULATOR PAGE
  const srvPage = document.getElementById('services-page');
  if (srvPage) {
    const classes = [
      { id: 'sedan', label: 'Седан / Хетчбек', mult: 1.0 },
      { id: 'crossover', label: 'Кросовер / SUV', mult: 1.2 },
      { id: 'suv', label: 'Позашляховик', mult: 1.4 },
      { id: 'minivan', label: 'Мінівен', mult: 1.55 }
    ];
    const pkgs = [
      { name: 'Повна хімчистка салону', base: 4800, hours: '6–8 год' },
      { name: 'Експрес-детейлінг салону', base: 2400, hours: '3 год' },
      { name: 'Преміум + Кераміка шкіри', base: 6900, hours: '8–10 год' },
      { name: 'Антизапах + Озонація PRO', base: 1650, hours: '2 год' }
    ];
    const zones = [
      { id: 'z1', name: 'Сидіння', price: 1800, hours: 2.5 },
      { id: 'z2', name: 'Стеля та стійки', price: 1100, hours: 1.5 },
      { id: 'z3', name: 'Ковролін підлоги', price: 1300, hours: 2.0 },
      { id: 'z4', name: 'Багажник', price: 750, hours: 1.0 },
      { id: 'z5', name: 'Захист шкіри', price: 1200, hours: 1.0 },
      { id: 'z6', name: 'Алькантара', price: 950, hours: 1.0 },
      { id: 'z7', name: 'Пластик і торпедо', price: 850, hours: 1.0 },
      { id: 'z8', name: 'Озонація салону', price: 700, hours: 0.8 }
    ];
    let curClass = 'crossover';
    let selZones = ['z1', 'z3'];

    function renderServices() {
      const cObj = classes.find(c => c.id === curClass);
      document.getElementById('class-switcher').innerHTML = classes.map(c => `
        <button type="button" data-cid="${c.id}" class="cls-btn px-3 py-2 text-xs font-bold rounded-[2px] ${c.id === curClass ? 'bg-[#00a0e3] text-white' : 'text-[#808191]'}">${c.label}</button>
      `).join('');
      document.getElementById('packages-grid').innerHTML = pkgs.map(p => {
        const pr = Math.round((p.base * cObj.mult) / 50) * 50;
        return `<div class="obsidian-card p-6 flex items-center justify-between gap-4">
          <div><div class="tech-mono text-[10px] text-[#00a0e3]">${p.hours}</div><div class="text-lg font-extrabold text-white mt-1">${p.name}</div></div>
          <div class="text-right"><div class="text-xl font-extrabold text-white">${pr} ₴</div><a href="/booking?service=${encodeURIComponent(p.name)}&carClass=${curClass}&price=${pr}" class="btn-main inline-block mt-2 px-4 py-2 text-xs">Обрати →</a></div>
        </div>`;
      }).join('');
      document.getElementById('zones-grid').innerHTML = zones.map(z => {
        const on = selZones.includes(z.id);
        const pr = Math.round((z.price * cObj.mult) / 50) * 50;
        return `<button type="button" data-zid="${z.id}" class="z-btn text-left p-4 rounded-[2px] border ${on ? 'bg-[#00a0e3]/15 border-[#00a0e3]' : 'bg-[#141318] border-[#2f2e38]'}">
          <div class="text-sm font-bold text-white">${z.name}</div>
          <div class="text-xs text-[#00a0e3] font-bold mt-1">${pr} ₴</div>
        </button>`;
      }).join('');
      const total = selZones.reduce((s, id) => s + Math.round((zones.find(z => z.id === id).price * cObj.mult) / 50) * 50, 0);
      const hrs = selZones.reduce((s, id) => s + zones.find(z => z.id === id).hours, 0);
      document.getElementById('z-count').textContent = selZones.length;
      document.getElementById('z-hours').textContent = hrs.toFixed(1) + ' год';
      document.getElementById('z-total').textContent = total + ' ₴';

      document.querySelectorAll('.cls-btn').forEach(b => b.addEventListener('click', () => { curClass = b.dataset.cid; renderServices(); }));
      document.querySelectorAll('.z-btn').forEach(b => b.addEventListener('click', () => {
        const id = b.dataset.zid;
        selZones = selZones.includes(id) ? selZones.filter(x => x !== id) : [...selZones, id];
        renderServices();
      }));
      document.getElementById('zones-book-btn').onclick = () => {
        const names = selZones.map(id => zones.find(z => z.id === id).name).join(', ');
        window.location.href = `/booking?service=${encodeURIComponent('Індивідуальний набір (' + selZones.length + ' зон)')}&carClass=${curClass}&price=${total}&comment=${encodeURIComponent('Зони: ' + names)}`;
      };
    }
    renderServices();
  }

  // WORKS FILTER
  document.querySelectorAll('.works-cat-filter').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.dataset.cat;
      document.querySelectorAll('.works-cat-filter').forEach(b => {
        const active = b.dataset.cat === cat;
        b.className = `works-cat-filter pill-tag px-3.5 py-1.5 text-xs font-semibold border ${active ? 'bg-[#00a0e3] text-white border-[#00a0e3]' : 'bg-[#09090a] text-[#d3cfdc] border-[#2f2e38]'}`;
      });
      document.querySelectorAll('.work-item').forEach(card => {
        card.style.display = (cat === 'Усі' || card.dataset.category === cat) ? '' : 'none';
      });
    });
  });

  // VACANCIES INLINE SUBMIT
  document.querySelectorAll('.vacancy-inline-form').forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const res = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'vacancy',
          vacancyTitle: form.dataset.vacancy,
          clientName: fd.get('clientName'),
          phone: fd.get('phone'),
          experience: fd.get('experience')
        })
      });
      if (res.ok) { form.reset(); toast('Відгук надіслано в CRM студії!'); }
    });
  });

  // BOOKING SUBMIT
  const bkForm = document.getElementById('node-booking-form');
  if (bkForm) {
    bkForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(bkForm);
      const res = await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'booking',
          carClass: fd.get('carClass'),
          carModel: fd.get('carModel'),
          serviceSummary: fd.get('serviceSummary'),
          dateSlot: fd.get('dateSlot'),
          estimatedPrice: Number(fd.get('estimatedPrice') || 0),
          clientName: fd.get('clientName'),
          phone: fd.get('phone'),
          comment: fd.get('comment')
        })
      });
      const data = await res.json();
      if (res.ok) { bkForm.reset(); toast(`Заявку #${data.application.id} прийнято!`); }
    });
  }

  // ADMIN ACTIONS
  const syncBtn = document.getElementById('node-sync-ig-btn');
  if (syncBtn) {
    syncBtn.addEventListener('click', async () => {
      toast('Синхронізація з Instagram Graph API...');
      const res = await fetch('/api/instagram/sync', { method: 'POST' });
      const data = await res.json();
      if (data.ok) {
        toast(`Готово! Нових постів: ${data.added}. Оновлюємо...`);
        setTimeout(() => location.reload(), 900);
      } else {
        toast(data.message || 'Помилка синхронізації');
      }
    });
  }

  const addCatBtn = document.getElementById('node-add-cat-btn');
  if (addCatBtn) {
    addCatBtn.addEventListener('click', async () => {
      const name = document.getElementById('node-new-cat').value.trim();
      if (!name) return;
      const res = await fetch('/api/categories', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) });
      if (res.ok) location.reload();
    });
  }

  document.querySelectorAll('.node-del-cat').forEach(btn => {
    btn.addEventListener('click', async () => {
      const res = await fetch('/api/categories/' + encodeURIComponent(btn.dataset.delCat), { method: 'DELETE' });
      if (res.ok) location.reload();
    });
  });

  document.querySelectorAll('.node-post-cat').forEach(sel => {
    sel.addEventListener('change', async () => {
      await fetch('/api/posts/' + sel.dataset.postId, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ category: sel.value }) });
      toast('Категорію оновлено');
    });
  });

  document.querySelectorAll('.node-post-pin').forEach(btn => {
    btn.addEventListener('click', async () => {
      const next = btn.dataset.featured !== 'true';
      await fetch('/api/posts/' + btn.dataset.postId, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ featured: next }) });
      location.reload();
    });
  });

  document.querySelectorAll('.node-post-pub').forEach(btn => {
    btn.addEventListener('click', async () => {
      const next = btn.dataset.published !== 'true';
      await fetch('/api/posts/' + btn.dataset.postId, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ published: next }) });
      location.reload();
    });
  });

  document.querySelectorAll('.node-app-status').forEach(sel => {
    sel.addEventListener('change', async () => {
      await fetch('/api/applications/' + sel.dataset.appId, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: sel.value }) });
      toast('Статус заявки збережено');
    });
  });

  const setForm = document.getElementById('node-settings-form');
  if (setForm) {
    setForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(setForm);
      const payload = Object.fromEntries(fd.entries());
      const res = await fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (res.ok) {
        toast('Налаштування студії збережено!');
        setTimeout(() => location.reload(), 700);
      }
    });
  }
})();
