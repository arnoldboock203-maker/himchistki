require('dotenv').config();
const express = require('express');
const path = require('path');
const { readDb } = require('./services/store');
const { syncFromInstagram } = require('./services/instagramSync');
const apiRouter = require('./routes/api');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Shared view locals for every multi-page route
app.use((req, res, next) => {
  const db = readDb();
  res.locals.db = db;
  res.locals.settings = db.settings;
  res.locals.publishedCount = db.igPosts.filter(p => p.published).length;
  res.locals.newAppsCount = db.applications.filter(a => a.status === 'new').length;
  res.locals.currentPath = req.path;
  next();
});

// REST API
app.use('/api', apiRouter);

// MULTI-PAGE ROUTES
app.get('/', (req, res) => {
  const published = res.locals.db.igPosts.filter(p => p.published);
  const featured = published.filter(p => p.featured).slice(0, 3);
  res.render('home', {
    pageTitle: 'Студія та огляд',
    sectionCode: '01 — СТУДІЯ ТА ОГЛЯД',
    showcase: featured.length ? featured : published.slice(0, 3)
  });
});

app.get('/services', (req, res) => {
  res.render('services', {
    pageTitle: 'Послуги та ціни',
    sectionCode: '02 — ПОСЛУГИ ТА КАЛЬКУЛЯТОР'
  });
});

app.get('/works', (req, res) => {
  const published = res.locals.db.igPosts
    .filter(p => p.published)
    .sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
  res.render('works', {
    pageTitle: 'Роботи з Instagram',
    sectionCode: '03 — ПОРТФОЛІО З INSTAGRAM',
    posts: published
  });
});

app.get('/vacancies', (req, res) => {
  res.render('vacancies', {
    pageTitle: 'Вакансії студії',
    sectionCode: '04 — ВАКАНСІЇ СТУДІЇ'
  });
});

app.get('/booking', (req, res) => {
  res.render('booking', {
    pageTitle: 'Онлайн-заявка',
    sectionCode: '05 — ОНЛАЙН-ЗАЯВКА',
    prefillService: req.query.service || 'Повна хімчистка салону',
    prefillClass: req.query.carClass || 'crossover',
    prefillPrice: Number(req.query.price || 5760),
    prefillComment: req.query.comment || ''
  });
});

app.get('/admin', (req, res) => {
  res.render('admin', {
    pageTitle: 'IG Куратор та Налаштування',
    sectionCode: 'ADMIN — IG КУРАТОР, CRM ТА НАЛАШТУВАННЯ',
    initialTab: req.query.tab || 'ig'
  });
});

// Optional periodic background Instagram sync
const syncMinutes = Number(process.env.INSTAGRAM_SYNC_MINUTES || 0);
if (syncMinutes > 0) {
  setInterval(async () => {
    try {
      const r = await syncFromInstagram();
      if (r.ok && r.added > 0) {
        console.log(`[IG Sync] Додано нових постів: ${r.added}`);
      }
    } catch (e) {
      console.error('[IG Sync] Помилка:', e.message);
    }
  }, syncMinutes * 60 * 1000);
}

app.listen(PORT, () => {
  console.log(`KRYSTAL BAY Node.js server running at http://localhost:${PORT}`);
});
